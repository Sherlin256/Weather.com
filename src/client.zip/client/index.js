import React from 'react';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));
